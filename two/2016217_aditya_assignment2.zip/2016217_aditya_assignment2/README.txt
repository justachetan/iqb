NOTE:

- The python version is Python 3.6
- You will have to install the libraries in requirements.txt to run this
  code
- The steps suggested below work only on a MacOS or Linux system

Suggested steps:

- Open your terminal
- Type 'virtualenv -p path/to/python3 assn2'
- Type 'source assn2/bin/activate'
- Type 'pip3 -r requirements.txt'
- Finally to run, type 'python3 analysis.py'


